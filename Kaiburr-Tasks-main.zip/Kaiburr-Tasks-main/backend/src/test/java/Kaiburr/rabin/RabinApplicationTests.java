package Kaiburr.rabin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabinApplicationTests {

	@Test
	void contextLoads() {
	}

}
