package com.kaiburr.rabin;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mainfile {
    public static void main(String[] args) {
        org.springframework.boot.SpringApplication.run(Mainfile.class, args);
    }
}
